public class Arrays {
    public static void main(String[] args) {
        List myList = new ArrayList();
	myList.add("P");
	myList.add("Q");
	myList.add("R");
    }
}
