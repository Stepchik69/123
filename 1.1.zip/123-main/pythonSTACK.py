stack = []

stack.append('a')
stack.append('b')
stack.append('c')
