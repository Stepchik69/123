#include <iostream>
#include <stack>
 
int main()
{
    std::stack<std::string> stack;

    stack.push("Tom");
    stack.push("Bob");
    stack.push("Sam");

}
